package com.amer.qufl;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.SystemClock;
import android.provider.Settings;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * يحفظ حالة القفل. الوقت المتبقي ينحسب بساعة الجهاز الداخلية (elapsedRealtime)
 * عشان تغيير الساعة من الإعدادات ما يقصّر المدة.
 */
public final class LockStore {
    private static final String PREFS = "lock";

    private LockStore() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static int bootCount(Context c) {
        try {
            return Settings.Global.getInt(c.getContentResolver(), Settings.Global.BOOT_COUNT);
        } catch (Exception e) {
            return -1;
        }
    }

    /** الوقت المتبقي بالملي ثانية (0 = ما فيه قفل). */
    public static synchronized long remaining(Context c) {
        SharedPreferences s = sp(c);
        long rem = s.getLong("rem", 0);
        if (rem <= 0) return 0;

        long el = SystemClock.elapsedRealtime();
        long wall = System.currentTimeMillis();
        int boot = bootCount(c);
        long lastEl = s.getLong("lastEl", el);
        long lastWall = s.getLong("lastWall", wall);
        int lastBoot = s.getInt("boot", boot);

        long passed;
        if (boot == lastBoot && el >= lastEl) {
            passed = el - lastEl;
        } else {
            // الجوال طفى وانفتح: نحسب الوقت اللي مر وهو طافي، بس ما يتعدى المتبقي
            passed = Math.max(0, Math.min(wall - lastWall, rem));
        }
        rem -= passed;

        SharedPreferences.Editor e = s.edit();
        if (rem <= 0) {
            rem = 0;
            e.putLong("rem", 0).remove("apps");
        } else {
            e.putLong("rem", rem);
        }
        e.putLong("lastEl", el).putLong("lastWall", wall).putInt("boot", boot).apply();
        return rem;
    }

    public static boolean isActive(Context c) {
        return remaining(c) > 0;
    }

    public static Set<String> apps(Context c) {
        return new HashSet<>(sp(c).getStringSet("apps", Collections.<String>emptySet()));
    }

    public static synchronized void start(Context c, Set<String> apps, long durationMs) {
        sp(c).edit()
                .putStringSet("apps", new HashSet<>(apps))
                .putLong("rem", durationMs)
                .putLong("total", durationMs)
                .putLong("lastEl", SystemClock.elapsedRealtime())
                .putLong("lastWall", System.currentTimeMillis())
                .putInt("boot", bootCount(c))
                .commit();
    }

    /** زيادة المدة فقط — ما فيه تقليل. */
    public static synchronized void extend(Context c, long addMs) {
        long rem = remaining(c);
        if (rem <= 0) return;
        SharedPreferences s = sp(c);
        s.edit().putLong("rem", rem + addMs).putLong("total", s.getLong("total", rem) + addMs).commit();
    }

    public static long total(Context c) {
        return sp(c).getLong("total", 0);
    }

    public static String format(long ms) {
        long sec = (ms + 999) / 1000;
        long d = sec / 86400;
        long h = (sec % 86400) / 3600;
        long m = (sec % 3600) / 60;
        long s = sec % 60;
        String t = String.format(java.util.Locale.US, "%02d:%02d:%02d", h, m, s);
        return d > 0 ? d + " يوم  " + t : t;
    }

    public static String describe(long ms) {
        long min = ms / 60000;
        long d = min / 1440, h = (min % 1440) / 60, m = min % 60;
        StringBuilder b = new StringBuilder();
        if (d > 0) b.append(d).append(" يوم ");
        if (h > 0) b.append(h).append(" ساعة ");
        if (m > 0) b.append(m).append(" دقيقة");
        return b.toString().trim();
    }
}
