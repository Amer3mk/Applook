package com.amer.qufl;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * الخدمة اللي تراقب التطبيق المفتوح. إذا كان مقفول ترجعك للرئيسية وتطلع شاشة القفل.
 * وخلال القفل تمنع فتح صفحات الإعدادات اللي فيها اسم التطبيق
 * (معلومات التطبيق / إيقاف إجباري / إلغاء التثبيت / إيقاف إمكانية الوصول).
 */
public class LockService extends AccessibilityService {

    private static final Set<String> GUARD = new HashSet<>(Arrays.asList(
            "com.android.settings",
            "com.android.vending",
            "com.google.android.packageinstaller",
            "com.android.packageinstaller",
            "com.samsung.android.packageinstaller",
            "com.google.android.permissioncontroller",
            "com.android.permissioncontroller",
            "com.miui.securitycenter",
            "com.coloros.safecenter",
            "com.huawei.systemmanager",
            "com.oplus.safecenter"
    ));

    private long lastBlock = 0;
    private long lastGuardCheck = 0;
    private String appLabel;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        appLabel = getApplicationInfo().loadLabel(getPackageManager()).toString();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        String pkg = event.getPackageName().toString();
        if (pkg.equals(getPackageName()) || pkg.equals("com.android.systemui")) return;
        if (!LockStore.isActive(this)) return;

        if (LockStore.apps(this).contains(pkg)) {
            block(pkg, false);
            return;
        }

        if (isGuarded(pkg)) {
            long now = SystemClock.elapsedRealtime();
            if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                    && now - lastGuardCheck < 400) return;
            lastGuardCheck = now;
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null && mentionsUs(root)) {
                block(pkg, true);
            }
        }
    }

    private boolean isGuarded(String pkg) {
        return GUARD.contains(pkg)
                || pkg.contains("settings")
                || pkg.contains("packageinstaller")
                || pkg.contains("securitycenter")
                || pkg.contains("safecenter");
    }

    private boolean mentionsUs(AccessibilityNodeInfo root) {
        if (appLabel == null) {
            appLabel = getApplicationInfo().loadLabel(getPackageManager()).toString();
        }
        List<AccessibilityNodeInfo> hits = root.findAccessibilityNodeInfosByText(appLabel);
        if (hits != null && !hits.isEmpty()) return true;
        hits = root.findAccessibilityNodeInfosByText(getPackageName());
        return hits != null && !hits.isEmpty();
    }

    private void block(String pkg, boolean guard) {
        long now = SystemClock.elapsedRealtime();
        if (now - lastBlock < 600) return;
        lastBlock = now;

        performGlobalAction(GLOBAL_ACTION_HOME);
        Intent i = new Intent(this, BlockActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra("pkg", pkg)
                .putExtra("guard", guard);
        try {
            startActivity(i);
        } catch (Exception ignored) {
            // حتى لو ما طلعت الشاشة، الرجوع للرئيسية صار
        }
    }

    @Override
    public void onInterrupt() {}
}
