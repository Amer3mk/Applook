package com.amer.qufl;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** الشاشة اللي تطلع إذا حاولت تفتح تطبيق مقفول. */
public class BlockActivity extends Activity {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView timer;
    private ImageView icon;
    private TextView title;
    private TextView sub;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            long rem = LockStore.remaining(BlockActivity.this);
            if (rem <= 0) {
                timer.setText("خلص القفل ✅");
                return;
            }
            timer.setText(LockStore.format(rem));
            handler.postDelayed(this, 1000);
        }
    };

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#0F1115"));
        getWindow().setNavigationBarColor(Color.parseColor("#0F1115"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.parseColor("#0F1115"));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(dp(28), dp(28), dp(28), dp(28));

        TextView lock = new TextView(this);
        lock.setText("🔒");
        lock.setTextSize(64);
        lock.setGravity(Gravity.CENTER);
        root.addView(lock);

        icon = new ImageView(this);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(56), dp(56));
        ip.topMargin = dp(12);
        root.addView(icon, ip);

        title = new TextView(this);
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(14), 0, dp(6));
        root.addView(title);

        sub = new TextView(this);
        sub.setTextColor(Color.parseColor("#9AA0AE"));
        sub.setTextSize(15);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);

        TextView label = new TextView(this);
        label.setText("يفتح بعد");
        label.setTextColor(Color.parseColor("#9AA0AE"));
        label.setTextSize(14);
        label.setGravity(Gravity.CENTER);
        label.setPadding(0, dp(36), 0, dp(4));
        root.addView(label);

        timer = new TextView(this);
        timer.setTextColor(Color.parseColor("#B9A8FF"));
        timer.setTextSize(42);
        timer.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        timer.setGravity(Gravity.CENTER);
        root.addView(timer);

        TextView back = new TextView(this);
        back.setText("رجوع للرئيسية");
        back.setTextColor(Color.WHITE);
        back.setTextSize(16);
        back.setTypeface(Typeface.DEFAULT_BOLD);
        back.setGravity(Gravity.CENTER);
        back.setPadding(dp(32), dp(14), dp(32), dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#7C5CFF"));
        bg.setCornerRadius(dp(28));
        back.setBackground(bg);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        bp.topMargin = dp(48);
        root.addView(back, bp);
        back.setOnClickListener(v -> goHome());

        setContentView(root);
        bind(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        bind(intent);
    }

    private void bind(Intent i) {
        String pkg = i.getStringExtra("pkg");
        boolean guard = i.getBooleanExtra("guard", false);
        if (guard) {
            title.setText("الإعدادات مقفولة الحين");
            sub.setText("ما تقدر توقف القفل أو تحذف التطبيق لين تخلص المدة 😉");
            icon.setVisibility(View.GONE);
        } else {
            String name = pkg;
            Drawable d = null;
            try {
                PackageManager pm = getPackageManager();
                name = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
                d = pm.getApplicationIcon(pkg);
            } catch (Exception ignored) {}
            title.setText(name + " مقفول");
            sub.setText("اصبر شوي… تقدر تسويها 💪");
            if (d != null) {
                icon.setImageDrawable(d);
                icon.setVisibility(View.VISIBLE);
            } else {
                icon.setVisibility(View.GONE);
            }
        }
    }

    private void goHome() {
        Intent h = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(h);
        finish();
    }

    @Override
    public void onBackPressed() {
        goHome();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
    }
}
