package com.amer.qufl;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Collator;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {

    static final int BG = Color.parseColor("#0F1115");
    static final int CARD = Color.parseColor("#1A1D24");
    static final int CARD2 = Color.parseColor("#242833");
    static final int ACCENT = Color.parseColor("#7C5CFF");
    static final int MUTED = Color.parseColor("#9AA0AE");
    static final int WARN = Color.parseColor("#FFB020");

    static final long MIN = 60_000L;
    static final long[] PRESETS = {15 * MIN, 30 * MIN, 60 * MIN, 120 * MIN, 240 * MIN, 480 * MIN, 1440 * MIN};
    static final String[] PRESET_NAMES = {"15 دقيقة", "30 دقيقة", "ساعة", "ساعتين", "4 ساعات", "8 ساعات", "يوم"};

    static class AppItem {
        String pkg;
        String name;
        Drawable icon;
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<AppItem> allApps = new ArrayList<>();
    private final List<AppItem> shown = new ArrayList<>();
    private final Set<String> selected = new HashSet<>();
    private long duration = 60 * MIN;

    private LinearLayout setupView, activeView, permCard;
    private TextView permText, permBtn, adminBtn, startBtn, countText, lockedList, loading;
    private final List<TextView> chips = new ArrayList<>();
    private TextView customChip;
    private AppsAdapter adapter;
    private String query = "";

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            refresh();
            handler.postDelayed(this, 1000);
        }
    };

    int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    GradientDrawable round(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    TextView button(String s, int color) {
        TextView b = text(s, 16, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(18), dp(14), dp(18), dp(14));
        b.setBackground(round(color, 16));
        return b;
    }

    LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(dp(16), dp(20), dp(16), dp(16));

        TextView h = text("🔒 قفل التطبيقات", 26, Color.WHITE, true);
        root.addView(h);
        TextView hs = text("اختار التطبيقات والمدة، وما راح تنفتح لين يخلص الوقت.", 14, MUTED, false);
        hs.setPadding(0, dp(4), 0, dp(12));
        root.addView(hs);

        // بطاقة الصلاحيات
        permCard = new LinearLayout(this);
        permCard.setOrientation(LinearLayout.VERTICAL);
        permCard.setBackground(round(CARD, 16));
        permCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        permText = text("", 14, Color.WHITE, false);
        permText.setLineSpacing(0, 1.25f);
        permCard.addView(permText);
        permBtn = button("تفعيل الخدمة", ACCENT);
        LinearLayout.LayoutParams pb = lp(-1, -2);
        pb.topMargin = dp(10);
        permCard.addView(permBtn, pb);
        permBtn.setOnClickListener(v -> openAccessibility());
        TextView restricted = text("الخيار رمادي وما ينضغط؟ اضغط هنا ← النقاط الثلاث فوق ← «السماح بالإعدادات المقيّدة»", 13, WARN, false);
        restricted.setPadding(0, dp(10), 0, 0);
        restricted.setOnClickListener(v -> openAppInfo());
        permCard.addView(restricted);
        LinearLayout.LayoutParams pc = lp(-1, -2);
        pc.bottomMargin = dp(12);
        root.addView(permCard, pc);

        setupView = buildSetup();
        root.addView(setupView, lp(-1, 0));
        ((LinearLayout.LayoutParams) setupView.getLayoutParams()).weight = 1;

        activeView = buildActive();
        root.addView(activeView, lp(-1, 0));
        ((LinearLayout.LayoutParams) activeView.getLayoutParams()).weight = 1;

        setContentView(root);
        loadApps();
    }

    private LinearLayout buildSetup() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);

        EditText search = new EditText(this);
        search.setHint("🔍  ابحث عن تطبيق");
        search.setHintTextColor(MUTED);
        search.setTextColor(Color.WHITE);
        search.setSingleLine(true);
        search.setBackground(round(CARD, 14));
        search.setPadding(dp(14), dp(12), dp(14), dp(12));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable s) {
                query = s.toString().trim().toLowerCase(Locale.ROOT);
                filter();
            }
        });
        v.addView(search, lp(-1, -2));

        loading = text("جاري تحميل التطبيقات…", 14, MUTED, false);
        loading.setPadding(0, dp(12), 0, 0);
        v.addView(loading);

        ListView list = new ListView(this);
        list.setDivider(null);
        list.setVerticalScrollBarEnabled(false);
        adapter = new AppsAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, view, pos, id) -> {
            AppItem a = shown.get(pos);
            if (!selected.remove(a.pkg)) selected.add(a.pkg);
            adapter.notifyDataSetChanged();
            updateStart();
        });
        LinearLayout.LayoutParams ll = lp(-1, 0);
        ll.weight = 1;
        ll.topMargin = dp(8);
        v.addView(list, ll);

        TextView dl = text("المدة", 15, Color.WHITE, true);
        dl.setPadding(0, dp(10), 0, dp(6));
        v.addView(dl);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < PRESETS.length; i++) {
            final long d = PRESETS[i];
            TextView c = chip(PRESET_NAMES[i]);
            c.setOnClickListener(x -> {
                duration = d;
                customChip.setText("مخصص ✏️");
                paintChips(x);
                updateStart();
            });
            chips.add(c);
            row.addView(c, chipLp());
        }
        customChip = chip("مخصص ✏️");
        customChip.setOnClickListener(x -> customDuration());
        chips.add(customChip);
        row.addView(customChip, chipLp());
        hs.addView(row);
        v.addView(hs);
        paintChips(chips.get(2));

        startBtn = button("ابدأ القفل", ACCENT);
        LinearLayout.LayoutParams sb = lp(-1, -2);
        sb.topMargin = dp(12);
        v.addView(startBtn, sb);
        startBtn.setOnClickListener(x -> confirmStart());
        return v;
    }

    private TextView chip(String s) {
        TextView c = text(s, 14, Color.WHITE, true);
        c.setPadding(dp(16), dp(10), dp(16), dp(10));
        return c;
    }

    private LinearLayout.LayoutParams chipLp() {
        LinearLayout.LayoutParams l = lp(-2, -2);
        l.setMarginEnd(dp(8));
        return l;
    }

    private void paintChips(View sel) {
        for (TextView c : chips) c.setBackground(round(c == sel ? ACCENT : CARD, 20));
    }

    private LinearLayout buildActive() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setGravity(Gravity.CENTER_HORIZONTAL);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setBackground(round(CARD, 20));
        card.setPadding(dp(16), dp(24), dp(16), dp(24));
        card.addView(text("القفل شغّال 🔒", 18, Color.WHITE, true));
        TextView l = text("باقي", 14, MUTED, false);
        l.setPadding(0, dp(12), 0, 0);
        card.addView(l);
        countText = text("", 44, Color.parseColor("#B9A8FF"), true);
        countText.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        card.addView(countText);
        v.addView(card, lp(-1, -2));

        TextView ll = text("التطبيقات المقفولة", 15, Color.WHITE, true);
        ll.setPadding(0, dp(18), 0, dp(6));
        v.addView(ll, lp(-1, -2));
        lockedList = text("", 15, MUTED, false);
        lockedList.setLineSpacing(0, 1.4f);
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.addView(lockedList);
        LinearLayout.LayoutParams svl = lp(-1, 0);
        svl.weight = 1;
        v.addView(sv, svl);

        TextView note = text("ما فيه زر إلغاء — هذا الهدف 😄 تقدر بس تزيد المدة:", 13, MUTED, false);
        note.setPadding(0, dp(8), 0, dp(8));
        v.addView(note, lp(-1, -2));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        TextView p15 = button("+15 دقيقة", CARD2);
        TextView p60 = button("+ساعة", CARD2);
        LinearLayout.LayoutParams a = lp(0, -2);
        a.weight = 1;
        a.setMarginEnd(dp(8));
        LinearLayout.LayoutParams c = lp(0, -2);
        c.weight = 1;
        row.addView(p15, a);
        row.addView(p60, c);
        p15.setOnClickListener(x -> { LockStore.extend(this, 15 * MIN); refresh(); });
        p60.setOnClickListener(x -> { LockStore.extend(this, 60 * MIN); refresh(); });
        v.addView(row, lp(-1, -2));

        adminBtn = button("🛡️ فعّل الحماية من الحذف", CARD2);
        LinearLayout.LayoutParams ab = lp(-1, -2);
        ab.topMargin = dp(8);
        v.addView(adminBtn, ab);
        adminBtn.setOnClickListener(x -> requestAdmin());
        return v;
    }

    // ---------- التطبيقات ----------

    private void loadApps() {
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> ris = pm.queryIntentActivities(main, 0);

            Set<String> skip = new HashSet<>();
            skip.add(getPackageName());
            Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            for (ResolveInfo r : pm.queryIntentActivities(home, 0)) skip.add(r.activityInfo.packageName);

            List<AppItem> out = new ArrayList<>();
            Set<String> seen = new HashSet<>();
            for (ResolveInfo r : ris) {
                String p = r.activityInfo.packageName;
                if (skip.contains(p) || !seen.add(p)) continue;
                AppItem a = new AppItem();
                a.pkg = p;
                a.name = r.loadLabel(pm).toString();
                a.icon = r.loadIcon(pm);
                out.add(a);
            }
            Collator col = Collator.getInstance(new Locale("ar"));
            out.sort((x, y) -> col.compare(x.name, y.name));
            runOnUiThread(() -> {
                allApps.clear();
                allApps.addAll(out);
                loading.setVisibility(View.GONE);
                filter();
                refresh();
            });
        }).start();
    }

    private void filter() {
        shown.clear();
        // المختارة أول
        for (AppItem a : allApps) if (selected.contains(a.pkg) && match(a)) shown.add(a);
        for (AppItem a : allApps) if (!selected.contains(a.pkg) && match(a)) shown.add(a);
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private boolean match(AppItem a) {
        return query.isEmpty() || a.name.toLowerCase(Locale.ROOT).contains(query)
                || a.pkg.toLowerCase(Locale.ROOT).contains(query);
    }

    class AppsAdapter extends BaseAdapter {
        public int getCount() { return shown.size(); }
        public Object getItem(int i) { return shown.get(i); }
        public long getItemId(int i) { return i; }

        public View getView(int i, View cv, ViewGroup parent) {
            LinearLayout row;
            if (cv == null) {
                row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(12), dp(10), dp(12), dp(10));
                row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                ImageView iv = new ImageView(MainActivity.this);
                row.addView(iv, lp(dp(40), dp(40)));
                TextView tv = text("", 16, Color.WHITE, false);
                tv.setPadding(dp(12), 0, dp(12), 0);
                tv.setSingleLine(true);
                LinearLayout.LayoutParams tl = lp(0, -2);
                tl.weight = 1;
                row.addView(tv, tl);
                CheckBox cb = new CheckBox(MainActivity.this);
                cb.setClickable(false);
                cb.setFocusable(false);
                cb.setButtonTintList(android.content.res.ColorStateList.valueOf(ACCENT));
                row.addView(cb);
                row.setLayoutParams(new android.widget.AbsListView.LayoutParams(-1, -2));
            } else {
                row = (LinearLayout) cv;
            }
            AppItem a = shown.get(i);
            boolean on = selected.contains(a.pkg);
            ((ImageView) row.getChildAt(0)).setImageDrawable(a.icon);
            ((TextView) row.getChildAt(1)).setText(a.name);
            ((CheckBox) row.getChildAt(2)).setChecked(on);
            row.setBackground(round(on ? Color.parseColor("#2A2342") : BG, 14));
            return row;
        }
    }

    // ---------- المدة والبدء ----------

    private void customDuration() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        box.setPadding(dp(8), dp(16), dp(8), dp(8));
        NumberPicker d = picker(0, 30, (int) (duration / (1440 * MIN)));
        NumberPicker h = picker(0, 23, (int) ((duration / (60 * MIN)) % 24));
        NumberPicker m = picker(0, 59, (int) ((duration / MIN) % 60));
        box.addView(column(d, "يوم"));
        box.addView(column(h, "ساعة"));
        box.addView(column(m, "دقيقة"));
        new AlertDialog.Builder(this)
                .setTitle("اختار المدة")
                .setView(box)
                .setPositiveButton("تم", (di, w) -> {
                    long total = d.getValue() * 1440 * MIN + h.getValue() * 60 * MIN + m.getValue() * MIN;
                    if (total < MIN) {
                        Toast.makeText(this, "أقل شي دقيقة", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    duration = total;
                    customChip.setText(LockStore.describe(total));
                    paintChips(customChip);
                    updateStart();
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private NumberPicker picker(int min, int max, int val) {
        NumberPicker p = new NumberPicker(this);
        p.setMinValue(min);
        p.setMaxValue(max);
        p.setValue(Math.max(min, Math.min(max, val)));
        return p;
    }

    private LinearLayout column(View v, String label) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(10), 0, dp(10), 0);
        c.addView(v);
        TextView t = new TextView(this);
        t.setText(label);
        t.setGravity(Gravity.CENTER);
        c.addView(t);
        return c;
    }

    private void updateStart() {
        if (startBtn == null) return;
        boolean ok = selected.size() > 0 && serviceOn();
        startBtn.setAlpha(ok ? 1f : 0.45f);
        String n = selected.isEmpty() ? "اختار تطبيقات" : "اقفل " + selected.size() + " تطبيق — " + LockStore.describe(duration);
        startBtn.setText(n);
    }

    private void confirmStart() {
        if (!serviceOn()) {
            Toast.makeText(this, "فعّل الخدمة أول", Toast.LENGTH_SHORT).show();
            openAccessibility();
            return;
        }
        if (selected.isEmpty()) {
            Toast.makeText(this, "اختار تطبيق واحد على الأقل", Toast.LENGTH_SHORT).show();
            return;
        }
        StringBuilder names = new StringBuilder();
        for (AppItem a : allApps) if (selected.contains(a.pkg)) names.append("• ").append(a.name).append("\n");
        new AlertDialog.Builder(this)
                .setTitle("متأكد؟ 🔒")
                .setMessage("بتقفل:\n" + names + "\nلمدة " + LockStore.describe(duration)
                        + "\n\nما تقدر تلغي القفل قبل ما تخلص المدة.")
                .setPositiveButton("اقفل", (d, w) -> {
                    LockStore.start(this, selected, duration);
                    selected.clear();
                    filter();
                    refresh();
                    if (!adminOn()) requestAdmin();
                })
                .setNegativeButton("تراجع", null)
                .show();
    }

    // ---------- الصلاحيات ----------

    private boolean serviceOn() {
        String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (s == null) return false;
        ComponentName cn = new ComponentName(this, LockService.class);
        for (String part : s.split(":")) {
            ComponentName c = ComponentName.unflattenFromString(part);
            if (cn.equals(c)) return true;
        }
        return false;
    }

    private boolean adminOn() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        return dpm != null && dpm.isAdminActive(new ComponentName(this, AdminReceiver.class));
    }

    private void requestAdmin() {
        if (adminOn()) return;
        Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, new ComponentName(this, AdminReceiver.class))
                .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "عشان ما تقدر تحذف التطبيق وأنت مقفّل على نفسك 😄");
        try { startActivity(i); } catch (Exception ignored) {}
    }

    private void openAccessibility() {
        try {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            Toast.makeText(this, "دوّر على «قفل التطبيقات» وفعّله", Toast.LENGTH_LONG).show();
        } catch (Exception ignored) {}
    }

    private void openAppInfo() {
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception ignored) {}
    }

    // ---------- تحديث الواجهة ----------

    private void refresh() {
        boolean on = serviceOn();
        long rem = LockStore.remaining(this);
        boolean active = rem > 0;

        if (!on) {
            permCard.setVisibility(View.VISIBLE);
            permText.setText(active
                    ? "⚠️ خدمة القفل طافية! شغّلها عشان يرجع القفل يشتغل."
                    : "خطوة وحدة قبل نبدأ: فعّل خدمة «قفل التطبيقات» من إعدادات إمكانية الوصول. هي اللي تعرف أي تطبيق انفتح وتقفله.");
        } else {
            permCard.setVisibility(View.GONE);
        }

        setupView.setVisibility(active ? View.GONE : View.VISIBLE);
        activeView.setVisibility(active ? View.VISIBLE : View.GONE);

        if (active) {
            countText.setText(LockStore.format(rem));
            StringBuilder b = new StringBuilder();
            PackageManager pm = getPackageManager();
            for (String p : LockStore.apps(this)) {
                String name = p;
                try { name = pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString(); } catch (Exception ignored) {}
                b.append("🔒  ").append(name).append("\n");
            }
            lockedList.setText(b.toString().trim());
            adminBtn.setVisibility(adminOn() ? View.GONE : View.VISIBLE);
        }
        updateStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
    }
}
