package com.amer.qufl;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;

/** صلاحية مسؤول الجهاز: تمنع حذف التطبيق إلا بعد إلغائها (وصفحة إلغائها مقفولة وقت القفل). */
public class AdminReceiver extends DeviceAdminReceiver {
    @Override
    public CharSequence onDisableRequested(Context context, Intent intent) {
        return "إذا ألغيت الحماية تقدر تحذف قفل التطبيقات.";
    }
}
